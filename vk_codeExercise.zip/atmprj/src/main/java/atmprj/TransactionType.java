package atmprj;

public enum TransactionType {
	DEPOSIT, WITHDRAW, NULL;
}
