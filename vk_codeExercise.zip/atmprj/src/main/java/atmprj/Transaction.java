package atmprj;

public abstract class Transaction {
	
}
